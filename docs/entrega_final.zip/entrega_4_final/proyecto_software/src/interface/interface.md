# Interface

## Cambios a solucionar

- Corregir la colocación de todas las llamadas a funciones que se encarguen de cambiar entre vistas de la interfaz (me quiero morir). Lo estoy poniendo todo en el controlador y ya lo que sea lógica de negocio se mueve a la parte de modelo posteriormente.

## Cambios propuestos

- Cuando se haya añadido la opción para cerrar sesión, los botones de la barra superior destinados a minimizar, maximizar y cerrar ventana serán únicamente visibles para el arch.
